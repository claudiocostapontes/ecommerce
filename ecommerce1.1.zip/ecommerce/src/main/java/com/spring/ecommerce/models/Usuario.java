package com.spring.ecommerce.models;

public class Usuario {

		// Atributos do Usuário
	
		private String cadeira_gamer;
		private String notebook;
		private String teclado;
		private String memoria;
		private String cabo;
		private String impressora;
		
		// Método Construtor
		
	public Usuario() {
		// TODO Auto-generated constructor stub
	}

	public String getCadeira_gamer() {
		return cadeira_gamer;
	}

	public void setCadeira_notebook(String cadeira_gamer) {
		this.cadeira_gamer = cadeira_gamer;
	}

	public String getNotebook() {
		return notebook;
	}

	public void setNotebook(String notebook) {
		this.notebook = notebook;
	}

	public String getTeclado() {
		return teclado;
	}

	public void setTeclado(String teclado) {
		this.teclado = teclado;
	}

	public String getMemoria() {
		return memoria;
	}

	public void setMemoria(String memoria) {
		this.memoria = memoria;
	}

	public String getCabo() {
		return cabo;
	}

	public void setCabo(String cabo) {
		this.cabo = cabo;
	}

	public String getImpressora() {
		return impressora;
	}

	public void setImpressora(String impressora) {
		this.impressora = impressora;
	}

}


package com.spring.ecommerce.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CommerceController {
	
	@RequestMapping("/incluirItens")
	public String IncluirItens() {
		return "commerce/incluir-itens";
		
	}

}
